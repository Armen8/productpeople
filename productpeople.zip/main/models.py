from django.db import models

# Create your models here.

class Users(models.Model):
    fullname = models.CharField(max_length=200, null=True, blank=True, verbose_name='Fullname')
    phone = models.CharField(max_length=100, null=True, blank=True, verbose_name='Phone')
    email = models.CharField(max_length=100, null=True, blank=True, verbose_name='Email')

    class Meta:
        verbose_name = 'Users'
        verbose_name_plural = 'Users'

    def __str__(self):
        return str(self.fullname)

class Courses(models.Model):
    course_name = models.CharField(max_length=100, null=True, blank=True, verbose_name='Course Name')
    teacher_name = models.CharField(max_length=100, null=True, blank=True, verbose_name='Teacher Name')
    teacher_description = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Teacher Description')
    start_date = models.CharField(max_length=100, null=True, blank=True, verbose_name='Start date')
    duration = models.CharField(max_length=100, null=True, blank=True, verbose_name='Duration')
    mini_description = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Mini Description')
    description1 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Description 1')
    description2 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Description 2')
    forwho1 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='For Who 1')
    forwho2 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='For Who 2')
    forwho3 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='For Who 3')
    what_you_will_learn1 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 1')
    what_you_will_learn2 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 2')
    what_you_will_learn3 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 3')
    what_you_will_learn4 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 4')
    what_you_will_learn5 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 5')
    what_you_will_learn6 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 6')
    what_you_will_learn7 = models.TextField(max_length=5000, null=True, blank=True, verbose_name='What you will learn 7')
    weeks = models.IntegerField(default=0, null=True, blank=True, verbose_name='Weeks')
    lectures = models.IntegerField(default=0, null=True, blank=True, verbose_name='Lectures')
    webinars = models.IntegerField(default=0, null=True, blank=True, verbose_name='Webinars')
    tasks = models.IntegerField(default=0, null=True, blank=True, verbose_name='Tasks')
    meetings = models.IntegerField(default=0, null=True, blank=True, verbose_name='Team Meetings')
    faq1_question = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Faq1 Question')
    faq1_answer = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Faq1 Answer')
    faq2_question = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Faq2 Question')
    faq2_answer = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Faq2 Answer')
    faq3_question = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Faq3 Question')
    faq3_answer = models.TextField(max_length=5000, null=True, blank=True, verbose_name='Faq3 Answer')

    class Meta:
        verbose_name = 'Courses'
        verbose_name_plural = 'Courses'

    def __str__(self):
        return str(self.course_name)