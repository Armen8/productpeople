document.querySelectorAll('.faqs aside').forEach(aside => {
    aside.addEventListener('click', () => {
        aside.classList.toggle('opened');
    });
});

if (document.querySelector('.intro button')) {
    document.querySelector('.intro button').addEventListener('click', () => {
        document.querySelector('.courses').scrollIntoView({
            behavior: 'smooth'
        });
    });
}

if (window.innerWidth < 1260) {
    document.querySelector('header').classList.add('mobile');
}

document.querySelector('header span.menu').addEventListener('click', () => {
    document.querySelector('header').classList.add('opened');

    try {
        document.getElementsByClassName('intro')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('courses')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('help')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('how')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('reviews')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('bid')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('faq')[0].style = 'filter: blur(8px);';
        document.getElementsByClassName('come')[0].style = 'filter: blur(8px);';
        }
    catch{
    document.getElementsByClassName('ux')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('about')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('who')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('teachers')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('learn')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('come')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('faq')[0].style = 'filter: blur(80px);';
    document.getElementsByClassName('bid')[0].style = 'filter: blur(80px);';
    }
});

document.querySelector('header nav .close').addEventListener('click', () => {
    document.querySelector('header').classList.remove('opened');

    try {
        document.getElementsByClassName('intro')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('courses')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('help')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('how')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('reviews')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('bid')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('faq')[0].style = 'filter: blur(0px);';
        document.getElementsByClassName('come')[0].style = 'filter: blur(0px);';
        }
    catch{
    document.getElementsByClassName('ux')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('about')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('who')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('teachers')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('learn')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('come')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('faq')[0].style = 'filter: blur(0px);';
    document.getElementsByClassName('bid')[0].style = 'filter: blur(0px);';
    }
});

if (document.querySelector('.ux div button') && document.querySelector('.bid button')) {
    document.querySelector('.ux div button').addEventListener('click', () => {
        document.querySelector('.bid button').scrollIntoView({
            behavior: 'smooth'
        });
    });
}

if (document.querySelector('.bid .telephone') && document.querySelector('.bid select')) {
    document.querySelector('.bid select').addEventListener('click', () => {
        document.querySelector('.bid .telephone').value = document.querySelector('.bid select').value;
    });
}
