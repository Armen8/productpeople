from django.contrib import admin
from . models import Courses, Users

# Register your models here.

admin.site.register(Users)
admin.site.register(Courses)
