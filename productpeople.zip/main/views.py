from django.shortcuts import render, redirect
from . models import Courses, Users
import requests

# Create your views here.

def index(request):
    if request.method == 'POST':
        fullname = request.POST['fullname']
        phone = request.POST['phone']
        email = request.POST['email']

        user = Users(fullname=fullname, phone=phone, email=email)
        user.save()

    courses = Courses.objects.all()
    data = {'courses': courses}
    return render(request, 'main/index.html', data)

def course(request):
    if request.method == 'GET':
        try:
            print(request.GET['id'])
            course = Courses.objects.all().get(id=request.GET['id'])
            data = {'course': course}
        except:
            return redirect('home')
        pass
    else:
        return redirect('home')

    if request.method == 'POST':
        fullname = request.POST['fullname']
        phone = request.POST['phone']
        email = request.POST['email']

        user = Users(fullname=fullname, phone=phone, email=email)
        user.save()
    return render(request, 'main/course.html', data)